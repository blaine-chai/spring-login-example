/**
 * Created by blainechai on 2016. 9. 30..
 */

(function($){




    $.fn.extend({
        customTable: function (options) {

        }
    });
}(customTable));