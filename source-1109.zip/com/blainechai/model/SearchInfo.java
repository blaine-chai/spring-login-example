package com.blainechai.model;

/**
 * Created by blainechai on 2016. 10. 16..
 */
public class SearchInfo {
}
