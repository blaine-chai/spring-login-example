package com.blainechai.constant;

/**
 * Created by blainechai on 2016. 9. 8..
 */
public final class UserType {
    public final static String ADMIN ="ADMIN";
    public final static String USER ="USER";
}
