package com.blainechai.constant;

/**
 * Created by blainechai on 2016. 9. 7..
 */
public final class Constant {
    public final static String JSESSIONID = "JSESSIONID";

}
