package com.blainechai.controller.api;

/**
 * Created by blainechai on 2016. 10. 13..
 */
public class SearchApi {
}
