package com.blainechai.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;

/**
 * Created by blainechai on 2016. 11. 16..
 */
public class TotalGraphModel {
    ArrayList<LinkedHashMap<String, String>> mapList;


}
